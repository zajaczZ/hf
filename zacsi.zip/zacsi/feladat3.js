class szemely{
    #teljesnev;
    #hobby;
    #eletkor;

    constructor(teljesnev,hobby,eletkor)
    {
        this.teljesnev = teljesnev;
        this.hobby = hobby;
        this.eletkor = eletkor;

    }
    get teljesnev (){
        return this.#teljesnev;
    }
    set teljesnev (value){
        this.#teljesnev = value;

    }
    get hobby (){
        return this.#hobby;
    }
    set hobby (value){
        this.#hobby = value;
    }
    get eletkor (){
        return this.#eletkor;
    }
    set eletkor (value)
    {
        this.#eletkor = value;
    }
    
    
       
    toString() {
        return `teljes név: ${this.#teljesnev} hobbi: ${this.#hobby} kor: ${this.#eletkor}`;
    }
    
      
    



}