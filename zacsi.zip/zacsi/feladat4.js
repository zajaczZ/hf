class Etel{
    #nev;
    #ar;
    #kateg;
    #osszetevok;
    constructor(nev,ar,kateg,osszetevok)
    {
        this.nev = nev;
        this.ar = ar;
        this.kateg = kateg;
        this.osszetevok = osszetevok;
    }

    get nev() {
        return this.#nev;
    }
    set nev(value) {
        this.#nev = value;
    }
    get ar() {
        return this.#ar;
    }
    set ar(value) {
        this.#ar = value;
    }
     get kateg() {
        return this.#kateg;
    }
    set kateg(value) {
        this.#kateg = value;
    }
    get osszetevok() {
        return this.#osszetevok;
    }
    set osszetevok(value) {
        this.#osszetevok = value;
    }
    ToString()
    {
        return `<tr>
        <td>${this.#nev}</td>
        <td>${this.#ar}</td>
        <td>${this.#kateg}</td>
        <td>${this.#osszetevok}</td>
        </tr>`;
        
        
        
    }

}